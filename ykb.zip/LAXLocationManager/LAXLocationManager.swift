//
//  LAXLocationManager.swift
//  MeiLiTV
//
//  Created by 冰凉的枷锁 on 2017/3/31.
//  Copyright © 2017年 冰凉的枷锁. All rights reserved.
//

import Foundation
import UIKit
import CoreLocation

class LAXLocationManager:CLLocationManager, CLLocationManagerDelegate {
    
    private var successBlock: ((_ address: String) -> Void)?
    private var failBlock: ((_ error: String) -> Void)?
    
    override init() {
        super.init()
        self.delegate = self
        self.desiredAccuracy = kCLLocationAccuracyBest
    }
    
    convenience init(getLocation success: @escaping (_ address: String) -> Void, failed: @escaping (_ error: String) -> Void) {
        self.init()
        self.getLocation(success: success, failed: failed)
    }
    
    func getLocation(success: @escaping (_ address: String) -> Void, failed: @escaping (_ error: String) -> Void) {
        self.successBlock = success
        self.failBlock = failed
        
        self.requestWhenInUseAuthorization()
        self.startUpdatingLocation()
    }
    
    // CLLocationManagerDelegate
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        if let location = locations.last {
            self.stopUpdatingLocation()
            let coor = location.coordinate
            let long = coor.longitude // 经度
            let lati = coor.latitude // 纬度
            print(long, lati)
            
            let geocoder = CLGeocoder.init()
            geocoder.reverseGeocodeLocation(location) { (placemarks, error) in
                
                if let name = placemarks?.first?.locality {
                  
                    self.successBlock?(name)
                } else {
                    self.failBlock?("抱歉，获取不到您的位置")
                }
                
            }
        }
        
    }
//    func LonLatToCity() {
//
//        let geocoder: CLGeocoder = CLGeocoder()
//
//        geocoder.reverseGeocodeLocation(currLocation) { (placemark, error) -> Void in
//
//
//
//            if(error == nil)//成功
//
//            {
//
//                let array = placemark! as NSArray
//
//                let mark = array.firstObject as! CLPlacemark
//
//                //这个是城市
//
//                let city: String = (mark.addressDictionary! as NSDictionary).valueForKey("City") as! String
//
//                //这个是国家
//
//                let country: NSString = (mark.addressDictionary! as NSDictionary).valueForKey("Country") as! NSString
//
//                //这个是国家的编码
//
//                let CountryCode: NSString = (mark.addressDictionary! as NSDictionary).valueForKey("CountryCode") as! NSString
//
//                //这是街道位置
//
//                let FormattedAddressLines: NSString = (mark.addressDictionary! as NSDictionary).valueForKey("FormattedAddressLines")?.firstObject as! NSString
//
//                //这是具体位置
//
//                let Name: NSString = (mark.addressDictionary! as NSDictionary).valueForKey("Name") as! NSString
//
//                //这是省
//
//                var State: String = (mark.addressDictionary! as NSDictionary).valueForKey("State") as! String
//
//                //这是区
//
//                let SubLocality: NSString = (mark.addressDictionary! as NSDictionary).valueForKey("SubLocality") as! NSString
//
//                //我在这里去掉了“省”和“市” 项目需求 可以忽略
//
//                State = State.stringByReplacingOccurrencesOfString("省", withString: "")
//
//                let citynameStr = city.stringByReplacingOccurrencesOfString("市", withString: "")
//
//                　　　　　　　　　　　　//在这里直接赋值给了之前定义的变量
//
//                self.provinces  = State
//
//                self.city = citynameStr
//
//                print( State)
//
//                print( citynameStr)
//
//                　　　　　　　　　　　　//下面的这个方法只有我和上帝知道它是干嘛用的  😀
//
//                self.saveLocationSearch([State,citynameStr])
//
//            }
//
//            else
//
//            {
//
//                print(error)
//
//                self.noticeOnlyText("定位好像失败了哦")
//
//            }
//
//        }
//
//    }
//

    
    
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        self.stopUpdatingLocation()
        var str = "未知错误"
        switch (error as NSError).code {
        case 0:
            str = "位置不可用"
            break
        case 1:
            str = "用户关闭"
            break
        default: break
        }
        print(str)
        self.failBlock?(str)
    }
    
}

