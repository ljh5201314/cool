//
//  AllTableViewCell.swift
//  ykb
//
//  Created by jd-ios on 2019/1/8.
//  Copyright © 2019 jd-ios. All rights reserved.
//

import UIKit

class AllTableViewCell: UITableViewCell {

    @IBOutlet var store_title: UILabel!
    
    @IBOutlet var store_address: UILabel!
    
    @IBOutlet var store_distance: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
