//
//  AllTableCollectionViewCell.swift
//  ykb
//
//  Created by jd-ios on 2019/1/10.
//  Copyright © 2019 jd-ios. All rights reserved.
//

import UIKit

class AllTableCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
