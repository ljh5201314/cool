//
//  firstPageViewcontoller.swift
//  ykb
//
//  Created by jd-ios on 2019/1/5.
//  Copyright © 2019 jd-ios. All rights reserved.
//

import UIKit
import SQAutoScrollView

class firstPageViewcontoller: UIViewController ,UISearchBarDelegate {
    
    @IBOutlet var search_bar: UISearchBar!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        
        self.navigationController!.navigationBar.shadowImage = UIImage()
        
        self.navigationController?.navigationBar.isTranslucent = true
        
       loadCycleView()
    
        // Do any additional setup after loading the view, typically from a nib.
//        let barButton = UIBarButtonItem(title: "other style", style: .plain, target: self, action: #selector(push))
//        navigationItem.rightBarButtonItem = barButton
        
      
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        search_bar.resignFirstResponder()
    }
    
  
    
    
        
    @objc func push() {
        navigationController?.pushViewController(firstPageViewcontoller(), animated: true)
    }
    
    fileprivate func loadCycleView() {
        
        let urls = ["https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1546848425843&di=6b9e12b20312794a430f476e4c28cade&imgtype=0&src=http%3A%2F%2Fi-1.52miji.com%2F2017%2F12%2F11%2F8588ac71-3c73-4327-a0a4-811c52934c21.jpg",
                    "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1546848592049&di=cf4ebae9323f66466cb2e524e7be4c95&imgtype=0&src=http%3A%2F%2Fi0.hdslb.com%2Fbfs%2Farchive%2Fa35849b838b9a24b6ef46824e5f579418d086168.jpg",
                    "http://pic.qyer.com/public/mobileapp/homebanner/2017/10/09/15075432049166/w800",
                    "http://pic.qyer.com/public/mobileapp/homebanner/2017/10/10/15076301267252/w800"
        ]
        
        let cycleView = SQAutoScrollView(frame: CGRect.init(x: 0, y: 100, width: view.bounds.size.width, height: 130), urls: urls, didItemCallBack: { (view, index) in
            print("view--->\(view), index-->\(index)")
        })
        view.addSubview(cycleView)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
   




    
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


}
//extension firstPageViewcontoller: UISearchBarDelegate {
//
//    func searchBarShouldBeginEditing(_ searchBar: UISearchBar) -> Bool {
//        print("将要开始编辑")
//        return true
//    }
//    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
//        print("已经开始编辑")
//    }
//    func searchBarShouldEndEditing(_ searchBar: UISearchBar) -> Bool {
//        print("将要结束编辑")
//        return true
//    }
//    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
//        print("已经结束编辑")
//    }
//    func searchBar(_ searchBar: UISearchBar, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
//        print("文本改变的时候触发 text: \(text)")
//        return true
//    }
//}

