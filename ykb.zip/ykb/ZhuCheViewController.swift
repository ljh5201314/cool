//
//  ZhuCheViewController.swift
//  ykb
//
//  Created by jd-ios on 2019/1/3.
//  Copyright © 2019 jd-ios. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class ZhuCheViewController: UIViewController {
 
    @IBOutlet var ycmm_image: UIButton!
    @IBOutlet var txt_mm: UITextField!
    
  
    var i = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func showMsgbox(_message: String, _title: String = "提示"){
        
        let alert = UIAlertController(title: _title, message: _message, preferredStyle: UIAlertController.Style.alert)
        let btnOK = UIAlertAction(title: "好的", style: .default, handler: nil)
        alert.addAction(btnOK)
        self.present(alert, animated: true, completion: nil)
        
    }
    
    @IBAction func show_mm(_ sender: Any) {
        i = i + 1
        if (i%2 == 1) {
            txt_mm.isSecureTextEntry = false
            ycmm_image.setBackgroundImage(UIImage(named:"see"), for: .normal)            
        }else{
            txt_mm.isSecureTextEntry = true
            ycmm_image.setBackgroundImage(UIImage(named:"unsee"), for: .normal)
        }
        
        
        
    }
    
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
