//
//  getyzmViewController.swift
//  ykb
//
//  Created by jd-ios on 2019/1/4.
//  Copyright © 2019 jd-ios. All rights reserved.
//

import UIKit
import SwiftyJSON

class getyzmViewController: UIViewController {

    @IBOutlet var sjh: UITextField!
    @IBOutlet var getyzm: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        let item = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
        self.navigationItem.backBarButtonItem = item;
        
    self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        
        self.navigationController!.navigationBar.shadowImage = UIImage()
        
        self.navigationController?.navigationBar.isTranslucent = true
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func get_yzm(_ sender: Any) {
        if(sjh.text == ""){
            return
        }
       // getUserBankInfo()
        getUserBankInfo()
    }
    
    
    
    func getUserBankInfo() {
        let parameters: NSMutableDictionary = NSMutableDictionary()
       // parameters["body"] = ["phone:"+sjh.text!,"type:1"]
//        parameters["phone"]=[sjh.text]
//        parameters["type"]=["1"]
        let score = sjh.text!
        let userid = "1"
        let body = "phone=\(score)&type=\(userid)"
        
        SSBaseNetWork.shareNetWorkBase.isNeedAccessToken = false
        SSBaseNetWork.shareNetWorkBase.RequestData(url:"sendmess", method: RequestMethod.RequestMethodPOST, params: body, success: { (jsonresult) in
            
            // 用 SwiftyJSON 解析数据
            let JSOnDictory = JSON(jsonresult )
            let data =  JSOnDictory["data"].array
            if (data?.count ?? 0 > 0){
                for dataDic in  data!
                {
                    let success = String(format:"%d",dataDic["success"].intValue )
                    let mess = dataDic["mess"].string ?? ""
                    print(success)
                    print(mess)
                    
                    //  self.zhuangtai.text = dataDic["DQZTMS"].string ?? ""
                    
                    
                    
                }
            }
            
        }) { (error) in
            print(error)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


