//
//  storeViewController.swift
//  ykb
//
//  Created by jd-ios on 2019/1/8.
//  Copyright © 2019 jd-ios. All rights reserved.
//

import UIKit
import SwiftyJSON
import CoreLocation

class teamModel: NSObject {
    var store_title = ""
    var store_address  = ""
    var store_distance = ""
    
}

class storeViewController:UIViewController,UITableViewDelegate,UITableViewDataSource {
     var manager: LAXLocationManager = LAXLocationManager.init()
    @IBOutlet var storeTabView: UITableView!
    
    @IBOutlet var city_label: UILabel!
    
    @IBAction func reload_location(_ sender: Any) {
        manager.getLocation(success: { (str) in
            self.city_label.text = str
        }) { (err) in
            self.city_label.text = err
        }
    }
    
        
        
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        let cellNib = UINib(nibName: "AllTableViewCell", bundle: nil)
        storeTabView.register(cellNib, forCellReuseIdentifier: "AllTableViewCell")
        //创建一个重用的单元格
        
        storeTabView.delegate = self
        storeTabView.dataSource = self
        
        self.DownLoadData()
        storeTabView.separatorStyle = UITableViewCell.SeparatorStyle.none
    self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        
        self.navigationController!.navigationBar.shadowImage = UIImage()
        
        self.navigationController?.navigationBar.isTranslucent = true
       // mySegmentControl()
        var myColor = UIColor(red: 6/255, green: 203/255, blue: 136/255,alpha: 0.5)
        
        //选项除了文字还可以是图片
        let items = ["全部", "店铺"] as [Any]
        let segmented = UISegmentedControl(items:items)
//        segmented.frame = CGRect(x: 0, y: 140, width: 375, height: 40)
//        segmented.selectedSegmentIndex = 1 //默认选中第二项
//        segmented.tintColor = myColor
        segmented.addTarget(self, action: #selector(storeViewController.segmentDidchange(_:)),
                            for: .valueChanged)  //添加值改变监听
        self.view.addSubview(segmented)
        segmented.frame = CGRect(x: 0, y: 120, width: 375, height: 40)
        segmented.setSegmentStyle(normalColor: UIColor.clear, selectedColor: myColor, dividerColor: myColor)
        segmented.selectedSegmentIndex = 0
        
       
      
    
      
        
        // Do any additional setup after loading the view.
    }
    
  
    
    
    // 数据源
    var dataArray = [teamModel]()
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataArray.count
    }
    
   
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: AllTableViewCell = tableView.dequeueReusableCell(withIdentifier: "AllTableViewCell") as! AllTableViewCell
        let model = self.dataArray[indexPath.row]
        cell.store_title.text = model.store_title
        cell.store_address.text = model.store_address
        cell.store_distance.text = model.store_distance
        
        return cell
        
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 62
    }
    
    // UITableViewDelegate 方法，处理列表项的选中事件
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //self.tableView!.deselectRow(at: indexPath, animated: true)
        //let itemString = self.ctrlnames[indexPath.row]
        
        //self.performSegue(withIdentifier: "activeDtl", sender: self)
    }
   
        
       
    @objc func segmentDidchange(_ segmented:UISegmentedControl){
        //获得选项的索引
        print(segmented.selectedSegmentIndex)
        
        if(segmented.selectedSegmentIndex == 0){
            print("点击了0")
        }else {
            print("点击了1")
        }
        //获得选择的文字
        print(segmented.titleForSegment(at: segmented.selectedSegmentIndex))
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
    
    func DownLoadData() -> Void {
        let parameters: NSMutableDictionary = NSMutableDictionary()
        parameters["body"] = ["team",_userId]
        //SSBaseNetWork.shareNetWorkBase.getJSONStringFromArray(array:arrBody as NSArray)
        SSBaseNetWork.shareNetWorkBase.isNeedAccessToken = false
        SSBaseNetWork.shareNetWorkBase.RequestData(url:"websrv.ashx", method: RequestMethod.RequestMethodPOST, params: parameters, success: { (jsonresult) in
            
            // 用 SwiftyJSON 解析数据
            let JSOnDictory = JSON(jsonresult )
            let data =  JSOnDictory["list"].array
            for dataDic in  data!
            {
                
                let model =  teamModel()
                //  ?? 这个符号，我怕有初学者忘记了的提醒一下，A ?? B  这是一个 NIL合并运算符，它的作用是如果 A 不是NIL 就返回前面可选类型参数 A 的确定值， 如果 A 是NIL 就返回后面 B 的值！A和B之间类型的注意点我就不说了，忘记了去看书，，哈哈哈
                
                model.store_title = dataDic["data1"].string ?? ""
                let  numString = String(format:"%d",dataDic["data5"].intValue )
                model.store_address =  numString
               
                model.store_distance =  dataDic["data2"].string ?? ""
    
                self.dataArray.append(model)
                
            }
            
            //self.storeTabView.reloadData()
            
            //print(jsonresult)
            
        }) { (error) in
            print(error)
        }
        
        
    }
    
    // MARK: 下载解析数据
    func DownLoadDataEx(acnt:String) -> Void {
        
        //dataArray.remo
        //var i = dataArray.count
        //        self.teamTable.beginUpdates()
        //        self.teamTable.deleteRows(at: [IndexPath.init(row: 0, section: <#T##Int#>)], with: UITableViewRowAnimation.automatic)
        //        self.teamTable.beginUpdates()
        //        while i >= 0 {
        //            dataArray.remove(at: i)
        //            i = i - 1
        //        }
        dataArray.removeAll()
        let parameters: NSMutableDictionary = NSMutableDictionary()
        parameters["body"] = ["teamex",acnt]
        //SSBaseNetWork.shareNetWorkBase.getJSONStringFromArray(array:arrBody as NSArray)
        SSBaseNetWork.shareNetWorkBase.isNeedAccessToken = false
        SSBaseNetWork.shareNetWorkBase.RequestData(url:"websrv.ashx", method: RequestMethod.RequestMethodPOST, params: parameters, success: { (jsonresult) in
            
            // 用 SwiftyJSON 解析数据
            let JSOnDictory = JSON(jsonresult )
            let data =  JSOnDictory["list"].array
            for dataDic in  data!
            {
                
                let model =  teamModel()
                //  ?? 这个符号，我怕有初学者忘记了的提醒一下，A ?? B  这是一个 NIL合并运算符，它的作用是如果 A 不是NIL 就返回前面可选类型参数 A 的确定值， 如果 A 是NIL 就返回后面 B 的值！A和B之间类型的注意点我就不说了，忘记了去看书，，哈哈哈
                
                model.store_title = dataDic["data1"].string ?? ""
                let  numString = String(format:"%d",dataDic["data5"].intValue )
                model.store_address =  numString
                model.store_distance =  dataDic["data2"].string ?? ""
              
                self.dataArray.append(model)
                
            }
            
            self.storeTabView.reloadData()
            
            //print(jsonresult)
            
        }) { (error) in
            print(error)
        }
        
        
    }
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension UIImage{
    public class func renderImageWithColor(_ color: UIColor, size: CGSize) -> UIImage {
        UIGraphicsBeginImageContext(size)
        guard let context = UIGraphicsGetCurrentContext() else {
            UIGraphicsEndImageContext()
            return UIImage()
        }
        context.setFillColor(color.cgColor);
        context.fill(CGRect(x: 0, y: 0, width: size.width, height: size.height));
        let img = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return img ?? UIImage()
    }
}
extension UISegmentedControl {
    
    /// 自定义样式
    ///
    /// - Parameters:
    ///   - normalColor: 普通状态下背景色
    ///   - selectedColor: 选中状态下背景色
    ///   - dividerColor: 选项之间的分割线颜色
    func setSegmentStyle(normalColor: UIColor, selectedColor: UIColor, dividerColor: UIColor) {
        
        let normalColorImage = UIImage.renderImageWithColor(normalColor, size: CGSize(width: 1.0, height: 1.0))
        let selectedColorImage = UIImage.renderImageWithColor(selectedColor, size: CGSize(width: 1.0, height: 1.0))
        let dividerColorImage = UIImage.renderImageWithColor(dividerColor, size: CGSize(width: 1.0, height: 1.0))
        
        setBackgroundImage(normalColorImage, for: .normal, barMetrics: .default)
        setBackgroundImage(selectedColorImage, for: .selected, barMetrics: .default)
        setDividerImage(dividerColorImage, forLeftSegmentState: .normal, rightSegmentState: .normal, barMetrics: .default)
        
        let segAttributesNormal: NSDictionary = [NSAttributedString.Key.foregroundColor: UIColor.gray, NSAttributedString.Key.font: UIFont.systemFont(ofSize: 16)]
        let segAttributesSeleted: NSDictionary = [NSAttributedString.Key.foregroundColor: UIColor.white,NSAttributedString.Key.font: UIFont.systemFont(ofSize: 18)]
        
        // 文字在两种状态下的颜色
        setTitleTextAttributes(segAttributesNormal as [NSObject : AnyObject] as [NSObject : AnyObject] as! [NSAttributedString.Key : Any], for: UIControl.State.normal)
        setTitleTextAttributes(segAttributesSeleted as [NSObject : AnyObject] as [NSObject : AnyObject] as! [NSAttributedString.Key : Any], for: UIControl.State.selected)
        
        // 边界颜色、圆角
        self.layer.borderWidth = 0.7
        self.layer.cornerRadius = 5.0
        self.layer.borderColor = dividerColor.cgColor
        self.layer.masksToBounds = true
    }
}

